class Product{
  final String name;
  final double price;
  final String img;

  Product({this.name, this.price, this.img});
}